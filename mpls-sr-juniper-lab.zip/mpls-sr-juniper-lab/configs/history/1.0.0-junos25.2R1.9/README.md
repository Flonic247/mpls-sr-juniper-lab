# History: release 1.0.0 (Junos 25.2R1.9)

The original, unmodified-except-sanitised R1 configuration before the two fixes made in release 1.1.0 (NET corrected, IS-IS metric 100 on `ge-0/0/0.0`). Kept so the audit finding C1 can be reproduced: `diff history/1.0.0-junos25.2R1.9/R1.set as-captured/R1.set`. The other seven devices did not change.
